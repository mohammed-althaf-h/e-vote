<footer>
        <p>&copy; <?php echo date('Y'); ?> E-Voting System. All rights reserved.</p>
    </footer>
</body>
</html>
