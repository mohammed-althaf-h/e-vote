<?php
session_start();

// Check if the user is logged in and is an admin
if (!isset($_SESSION['registerno']) || $_SESSION['isadmin'] != 1) {
    header("Location: ../auth/login.php");
    exit();
}

// Include database connection
include '../includes/db.php';

// Handle eligibility change request
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['change_eligibility'])) {
    $registerno = $_POST['registerno'];
    $new_eligibility = $_POST['eligible'] ? 0 : 1;
    $sql = "UPDATE users SET eligible = ? WHERE registerno = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $new_eligibility, $registerno);
    $stmt->execute();
    $stmt->close();
}

// Retrieve users from the database
$sql = "SELECT registerno, email, verified, eligible FROM users";
$result = $conn->query($sql);

$users = array();
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Users</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <a class="navbar-brand" href="#">Admin Panel</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="../index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="dashboard.php">Admin Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="add_candidate.php">Add Candidate</a></li>
                    <li class="nav-item"><a class="nav-link" href="manage_candidates.php">Manage Candidates</a></li>
                    <li class="nav-item"><a class="nav-link" href="../logout.php">Logout</a></li>
                </ul>
            </div>
        </nav>
    </header>
    <div class="container mt-5">
        <h2>View Users</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Register Number</th>
                    <th>Email</th>
                    <th>Verified</th>
                    <th>Eligible</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td><?php echo htmlspecialchars($user['registerno']); ?></td>
                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                    <td><?php echo $user['verified'] ? 'Yes' : 'No'; ?></td>
                    <td><?php echo $user['eligible'] ? 'Yes' : 'No'; ?></td>
                    <td>
                        <form action="view_users.php" method="post" style="display:inline;">
                            <input type="hidden" name="registerno" value="<?php echo htmlspecialchars($user['registerno']); ?>">
                            <input type="hidden" name="eligible" value="<?php echo $user['eligible']; ?>">
                            <input type="submit" name="change_eligibility" class="btn btn-secondary" value="<?php echo $user['eligible'] ? 'Set Not Eligible' : 'Set Eligible'; ?>">
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
