<?php
session_start();

// Check if the user is logged in and is an admin
if (!isset($_SESSION['registerno']) || $_SESSION['isadmin'] != 1) {
    header("Location: ../auth/login.php");
    exit();
}

// Include database connection
include '../includes/db.php';

// Fetch current voting status
$sql = "SELECT voting_enabled FROM settings WHERE id = 1";
$result = $conn->query($sql);
$voting_enabled = false;
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $voting_enabled = $row['voting_enabled'];
}

// Handle form submission to toggle voting
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_status = $voting_enabled ? 0 : 1;

    $sql = "UPDATE settings SET voting_enabled = ? WHERE id = 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $new_status);
    if ($stmt->execute()) {
        $voting_enabled = $new_status;
    } else {
        echo "Something went wrong. Please try again.";
    }
    $stmt->close();
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
         .navbar {
            margin-bottom: 20px;
            background-color: #000000;
        }
        </style>
</head>
<body>
    <header>
    <nav class="navbar navbar-expand-lg navbar-dark">
            <a class="navbar-brand" href="#">Admin Panel</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="../index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="view_users.php">View Users</a></li>
                    <li class="nav-item"><a class="nav-link" href="add_candidate.php">Add Candidate</a></li>
                    <li class="nav-item"><a class="nav-link" href="manage_candidates.php">Manage Candidates</a></li>
                    <li class="nav-item"><a class="nav-link" href="../logout.php">Logout</a></li>
                </ul>
            </div>
        </nav>
    </header>
    <div class="container mt-5">
        <h2>Admin Dashboard</h2>
        <form action="dashboard.php" method="post">
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="<?php echo $voting_enabled ? 'Disable Voting' : 'Enable Voting'; ?>">
            </div>
        </form>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
