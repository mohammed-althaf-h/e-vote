<?php
session_start();

// Check if the user is logged in and is an admin
if (!isset($_SESSION['registerno']) || $_SESSION['isadmin'] != 1) {
    header("Location: ../auth/login.php");
    exit();
}

// Include database connection
include '../includes/db.php';

// Handle delete candidate request
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_candidate'])) {
    $candidate_id = $_POST['candidate_id'];
    $sql = "DELETE FROM candidates WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $candidate_id);
    $stmt->execute();
    $stmt->close();
}

// Handle edit candidate request
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_candidate'])) {
    $candidate_id = $_POST['candidate_id'];
    $name = $_POST['name'];
    $position_id = $_POST['position_id'];
    $image_url = $_POST['image_url'];

    $sql = "UPDATE candidates SET name = ?, position_id = ?, image_url = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sisi", $name, $position_id, $image_url, $candidate_id);
    $stmt->execute();
    $stmt->close();
}

// Retrieve candidates from the database
$sql = "SELECT c.id, c.name, c.image_url, p.name AS position_name, p.id AS position_id 
        FROM candidates c 
        INNER JOIN positions p ON c.position_id = p.id";
$result = $conn->query($sql);

$candidates = array();
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $candidates[] = $row;
    }
}

// Retrieve positions from the database for the edit form
$sql = "SELECT id, name FROM positions";
$result = $conn->query($sql);

$positions = array();
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $positions[] = $row;
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Candidates</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script>
        function editCandidate(id, name, position_id, image_url) {
            document.getElementById('edit_candidate_id').value = id;
            document.getElementById('edit_name').value = name;
            document.getElementById('edit_position_id').value = position_id;
            document.getElementById('edit_image_url').value = image_url;
            document.getElementById('editForm').style.display = 'block';
        }
    </script>
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <a class="navbar-brand" href="#">Admin Panel</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="../index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="dashboard.php">Admin Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="view_users.php">View Users</a></li>
                    <li class="nav-item"><a class="nav-link" href="add_candidate.php">Add Candidate</a></li>
                    <li class="nav-item"><a class="nav-link" href="../logout.php">Logout</a></li>
                </ul>
            </div>
        </nav>
    </header>
    <div class="container mt-5">
        <h2>Manage Candidates</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Position</th>
                    <th>Image URL</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($candidates as $candidate): ?>
                <tr>
                    <td><?php echo htmlspecialchars($candidate['name']); ?></td>
                    <td><?php echo htmlspecialchars($candidate['position_name']); ?></td>
                    <td><?php echo htmlspecialchars($candidate['image_url']); ?></td>
                    <td>
                        <form action="manage_candidates.php" method="post" style="display:inline;">
                            <input type="hidden" name="candidate_id" value="<?php echo htmlspecialchars($candidate['id']); ?>">
                            <input type="submit" name="delete_candidate" class="btn btn-danger" value="Delete">
                        </form>
                        <button class="btn btn-primary" onclick="editCandidate('<?php echo htmlspecialchars($candidate['id']); ?>', '<?php echo htmlspecialchars(addslashes($candidate['name'])); ?>', '<?php echo htmlspecialchars($candidate['position_id']); ?>', '<?php echo htmlspecialchars(addslashes($candidate['image_url'])); ?>')">Edit</button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div id="editForm" style="display:none;">
            <h3>Edit Candidate</h3>
            <form action="manage_candidates.php" method="post">
                <input type="hidden" name="candidate_id" id="edit_candidate_id">
                <div class="form-group">
                    <label for="edit_name">Name:</label>
                    <input type="text" name="name" id="edit_name" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="edit_position_id">Position:</label>
                    <select name="position_id" id="edit_position_id" class="form-control" required>
                        <?php foreach ($positions as $position): ?>
                            <option value="<?php echo $position['id']; ?>"><?php echo htmlspecialchars($position['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="edit_image_url">Image URL:</label>
                    <input type="text" name="image_url" id="edit_image_url" class="form-control">
                </div>
                <div class="form-group">
                    <input type="submit" name="edit_candidate" class="btn btn-primary" value="Update">
                </div>
            </form>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
